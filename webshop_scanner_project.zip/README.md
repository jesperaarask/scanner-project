# Webshop Scanner

Dette projekt er en komplet webapplikation der tillader brugere at indsætte et link til en webshop, scanner linket for sikkerhed via Google Safe Browsing API, gemmer historik over hvor mange gange hvert link er blevet scannet, og viser en professionel brugerflade.

## Funktioner

- Validering af URL
- Sikkerhedstjek via Google Safe Browsing
- Gemmer og viser historik
- Responsiv og moderne frontend

## Installation og Hosting på Render.com

1. **Krav**:
   - Python 3.8+
   - En Google Safe Browsing API-nøgle (kan oprettes via https://developers.google.com/safe-browsing)

2. **Opsætning**:
   - Opret en konto på [Render.com](https://render.com)
   - Opret et nyt Web Service projekt
   - Upload hele projektmappen (zip-filen)
   - Vælg Python som miljø
   - Tilføj følgende miljøvariabel:
     - `GOOGLE_SAFE_BROWSING_API_KEY`: Din API-nøgle fra Google Safe Browsing
   - Sørg for at `requirements.txt` indeholder de nødvendige pakker

3. **Start applikationen**:
   - Render vil automatisk installere afhængigheder og starte serveren
   - Din webshop scanner er nu online og klar til brug!
